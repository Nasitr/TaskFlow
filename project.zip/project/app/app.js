const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Set Pug as the templating engine
app.set("view engine", "pug");
app.set("views", path.resolve(__dirname, "../view"));

// Serve static files from the "static" folder
app.use(express.static(path.join(__dirname, "static")));
// Define routes
app.get("/", (req, res) => {
  res.render("index", { title: "Home" });
});

app.get("/project", (req, res) => {
  res.render("project", { title: "Project" });
});

app.get("/signin", (req, res) => {
  res.render("signin", { title: "Sign In" });
});

app.get("/team", (req, res) => {
  res.render("team", { title: "Team" });
});

// Export the Express app
module.exports = app;

